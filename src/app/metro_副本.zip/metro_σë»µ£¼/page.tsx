import MetroControl from "./metroControl";


export default function Metro() {
    return (
        <div>
            <MetroControl />
        </div>
    );
}
